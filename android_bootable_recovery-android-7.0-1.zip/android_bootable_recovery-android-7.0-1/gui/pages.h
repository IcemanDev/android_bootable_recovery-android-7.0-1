#ifndef _PAGES_HEADER
#define _PAGES_HEADER

void gui_notifyVarChange(const char *name, const char* value);

#endif  // _PAGES_HEADER

